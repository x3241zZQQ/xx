export const API_ENDPOINTS = {
    MIGROS: {
        BASE_URL: 'https://rest.migros.com.tr',
        CART: '/delivery/cart',
        ADDRESS: '/address',
        LOGIN: '/auth/login'
    },
    
    TGOYEMEK: {
        BASE_URL: 'https://api.tgoapis.com',
        CSRF: 'https://tgoyemek.com/api/auth/csrf',
        LOGIN: 'https://tgoyemek.com/api/auth/login',
        ADDRESSES: '/web-user-apimemberaddress-santral/addresses'
    },
    
    YEMEKSEPETI: {
        BASE_URL: 'https://tr.fd-api.com/api/v5',
        TOKEN: '/oauth2/token',
        CART_CALCULATE: '/cart/calculate',
        CART_CHECKOUT: '/cart/checkout',
        INCENTIVES: '/api/v6/incentives-wallet'
    },
    
    YEKUPON: {
        BASE_URL: 'https://yekupon.com',
        COOKIES: '/cookies'
    }
};

export const URL_PATTERNS = {
    MIGROS: ['https://*.migros.com.tr/*', 'https://migros.com.tr/*'],
    TGOYEMEK: ['https://tgoyemek.com/*', 'https://*.tgoyemek.com/*'],
    YEMEKSEPETI: ['https://*.yemeksepeti.com/*', 'https://www.yemeksepeti.com/*']
};
