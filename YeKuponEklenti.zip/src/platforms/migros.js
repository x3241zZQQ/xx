import { generateRandomHex, generateTurkishIP, sendLogMessage } from '../core/helpers.js';
import { API_ENDPOINTS } from '../core/endpoints.js';

/**
 * Handle Migros login process
 */
export async function handleMigrosLogin(data, token, tabId) {
    try {
        await sendLogMessage("Migros giri� i�lemi ba�lat�l�yor...", "info", tabId, "MIGROS");
        
        const response = await fetch(`${API_ENDPOINTS.YEKUPON.BASE_URL}${API_ENDPOINTS.YEKUPON.COOKIES}/${token}`);
        
        if (!response.ok) {
            throw new Error(`YeKupon sunucusu hatas�: ${response.status}`);
        }
        
        const responseData = await response.json();
        console.log('?? YeKupon sunucusundan al�nan RAW veri:', responseData);
        
        const cookiesArray = responseData.data || responseData;
        
        if (!Array.isArray(cookiesArray)) {
            throw new Error('YeKupon sunucusundan ge�ersiz veri format� al�nd�');
        }
        
        console.log('?? Al�nan �erezler:', cookiesArray.map(c => ({
            name: c.name,
            valueLength: c.value.length,
            domain: c.domain,
            path: c.path
        })));
        
        const importantCookies = ['VSTR_ID', 'CLIENT_SESSION_ID', 'remember-me', 'SESSION'];
        const foundImportantCookies = cookiesArray.filter(c => importantCookies.includes(c.name));
        console.log('?? Bulunan �nemli �erezler:', foundImportantCookies.map(c => c.name));
        
        if (foundImportantCookies.length === 0) {
            console.error('?? H��B�R �NEML� �EREZ BULUNAMADI! Migros API �al��mayacak');
        }
        
        const cookieString = cookiesArray.map(cookie => `${cookie.name}=${cookie.value}`).join('; ');
        
        console.log('?? Migros cookie string haz�rland� (length:', cookieString.length, ')');
        
        const migrosUserData = {
            cookies: cookiesArray,
            cookieString: cookieString
        };
        
        await performMigrosAddressOperations(migrosUserData, tabId);
        
        await redirectToMigrosYemek(migrosUserData, tabId);
        
    } catch (error) {
        console.error('Migros giri� hatas�:', error);
        await sendLogMessage(`Migros giri� hatas�: ${error.message}`, "error", tabId, "MIGROS");
    }
}

/**
 * Migros API request handler with CORS solution
 */
export async function handleMigrosAPIRequest(request, sendResponse) {
    try {
        console.log('Migros API proxy iste�i:', request.url, request.method || 'GET');
        
        const headers = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
            'Sec-Ch-Ua': '"Chromium";v="120", "Not_A Brand";v="24", "Google Chrome";v="120"',
            'Sec-Ch-Ua-Mobile': '?1',
            'Sec-Ch-Ua-Platform': '"Android"',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Origin': 'https://www.migros.com.tr',
            'Referer': 'https://www.migros.com.tr/',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-G981B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
            'Upgrade-Insecure-Requests': '1',
            'Dnt': '1',
            'Connection': 'keep-alive'
        };
        
        if (request.method === 'POST' && request.body) {
            headers['Content-Type'] = 'application/json; charset=UTF-8';
        }
        
        if (request.headers) {
            Object.assign(headers, request.headers);
        }
        
        const cookies = await new Promise((resolve) => {
            chrome.cookies.getAll({ domain: '.migros.com.tr' }, (cookies) => {
                resolve(cookies);
            });
        });
        
        if (cookies.length > 0) {
            const cookieString = cookies.map(c => `${c.name}=${c.value}`).join('; ');
            headers['Cookie'] = cookieString;
            console.log('Migros API PROXY: Cookie\'ler eklendi:', cookies.length + ' adet');
        }
        
        const fetchOptions = {
            method: request.method || 'GET',
            headers: headers
        };
        
        if (request.method === 'POST' && request.body) {
            fetchOptions.body = typeof request.body === 'string' ? request.body : JSON.stringify(request.body);
        }
        
        const response = await fetch(request.url, fetchOptions);
        
        console.log('Migros API yan�t�:', {
            status: response.status,
            statusText: response.statusText
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText.substring(0, 200)}`);
        }
        
        const contentType = response.headers.get('content-type');
        let data;
        
        if (contentType && contentType.includes('application/json')) {
            data = await response.json();
        } else {
            data = await response.text();
        }
        
        sendResponse({
            success: true,
            data: data,
            status: response.status,
            headers: Object.fromEntries(response.headers.entries())
        });
        
    } catch (error) {
        console.error('Migros API proxy hatas�:', error);
        
        sendResponse({
            success: false,
            error: error.message,
            status: error.status || 500
        });
    }
}

/**
 * Redirect to Migros Yemek page
 */
async function redirectToMigrosYemek(userData, tabId) {
    try {
        await sendLogMessage("Migros yemek sayfas�na y�nlendiriliyor...", "info", tabId, "MIGROS");
        
        const importantCookies = userData.cookies.filter(cookie => 
            cookie.name === 'remember-me' || cookie.name === 'SESSION'
        );
        
        if (importantCookies.length > 0) {
            await sendLogMessage("Gerekli �erezler Chrome'a aktar�l�yor...", "info", tabId, "MIGROS");
            
            for (const cookie of importantCookies) {
                try {
                    await new Promise((resolve, reject) => {
                        const cookieData = {
                            url: "https://www.migros.com.tr",
                            name: cookie.name,
                            value: cookie.value,
                            path: cookie.path || "/",
                            secure: cookie.secure !== false,
                            httpOnly: cookie.httpOnly !== false
                        };
                        
                        if (cookie.domain) {
                            cookieData.domain = cookie.domain;
                        }
                        
                        chrome.cookies.set(cookieData, (result) => {
                            if (chrome.runtime.lastError) {
                                console.error(`�erez set etme hatas� (${cookie.name}):`, chrome.runtime.lastError.message);
                            } else {
                                console.log(`? �erez set edildi: ${cookie.name}`);
                            }
                            resolve();
                        });
                    });
                } catch (error) {
                    console.error(`�erez set etme hatas� (${cookie.name}):`, error);
                }
            }
        }
        
        chrome.tabs.create({
            url: "https://www.migros.com.tr/yemek",
            active: true
        });
        
        await sendLogMessage("? Migros giri� tamamland�!", "success", tabId, "MIGROS");
        
    } catch (error) {
        console.error('Migros y�nlendirme hatas�:', error);
        await sendLogMessage(`? Y�nlendirme hatas�: ${error.message}`, "error", tabId, "MIGROS");
    }
}

/**
 * Perform Migros address operations
 */
async function performMigrosAddressOperations(userData, tabId) {
    console.log('Migros address operations started');
}
