
/**
 * Random string generators
 */
export function randomString(length) {
    let generated = '';
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < length; i++) {
        generated += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return generated;
}

export function randomDigits(length) {
    let result = '';
    for (let i = 0; i < length; i++) {
        result += Math.floor(Math.random() * 10).toString();
    }
    return result;
}

export function generateRandomHex(length) {
    const chars = '0123456789abcdef';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars[Math.floor(Math.random() * chars.length)];
    }
    return result;
}

/**
 * Device information generators
 */
export function generateRandomDevice() {
    const makes = ["Xiaomi", "HUAWEI", "Redmi", "Samsung", "POCO", "oppo", "Asus"];
    const deviceMake = makes[Math.floor(Math.random() * makes.length)];
    
    const models = ["CPH2341", "M2101K6G", "M2004J19C", "2201116TG", "2207117BPG", "ASUS_I005DA", "ASUS_Z01QD"];
    const deviceModel = models[Math.floor(Math.random() * models.length)];
    
    const platformVersion = 23 + Math.floor(Math.random() * 10);
    const deviceId = randomString(32);
    
    return {
        deviceId,
        deviceMake,
        deviceModel,
        platformVersion
    };
}

/**
 * UUID and token generators
 */
export function generateUUIDv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
        const r = Math.random() * 16 | 0;
        const v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

export function generateTurkishIP() {
    const turkishIPRanges = [
        [81, 213], [85, 96], [88, 240], [94, 54], [95, 70],
        [176, 235], [185, 42], [188, 119], [212, 58], [213, 74]
    ];
    
    const range = turkishIPRanges[Math.floor(Math.random() * turkishIPRanges.length)];
    const thirdOctet = Math.floor(Math.random() * 256);
    const fourthOctet = Math.floor(Math.random() * 256);
    
    return `${range[0]}.${range[1]}.${thirdOctet}.${fourthOctet}`;
}

/**
 * Date and time utilities
 */
export function getUnixTime() {
    return Math.floor(Date.now() / 1000);
}

export function generateOriginalRts() {
    const now = new Date();
    const turkeyTime = new Date(now.getTime() + (3 * 60 * 60 * 1000));
    return turkeyTime.toISOString().replace('Z', '+03:00');
}

/**
 * Cookie utilities
 */
export async function getSavedUserData() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['yekupon_user_data'], (result) => {
            resolve(result.yekupon_user_data || null);
        });
    });
}

/**
 * Logging utilities
 */
export async function sendLogMessage(message, type, tabId, platform = 'SYSTEM') {
    try {
        if (tabId) {
            chrome.tabs.sendMessage(tabId, {
                action: 'updateLog',
                message: `[${platform}] ${message}`,
                type: type
            });
        }
        console.log(`[${platform}] ${message}`);
    } catch (error) {
        console.log(`[${platform}] ${message}`);
    }
}

/**
 * Validation utilities
 */
export function validateDomain(domain) {
    if (!domain || domain.includes('404') || domain.includes('Not Found') || 
        domain.includes('<') || domain.includes('>') || domain.length < 3) {
        return false;
    }
    
    domain = domain.replace(/^https?:\/\//, '');
    
    const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]?\.[a-zA-Z]{2,}$/;
    return domainRegex.test(domain);
}
