import { 
    randomString, 
    generateRandomHex, 
    generateUUIDv4, 
    generateRandomDevice,
    sendLogMessage,
    validateDomain
} from '../core/helpers.js';
import { API_ENDPOINTS } from '../core/endpoints.js';

/**
 * Main YemekSepeti setup process
 */
export async function setupYemekSepeti(token) {
    try {
        const createdTab = await new Promise((resolve) => {
            chrome.tabs.create({ url: 'https://www.yemeksepeti.com' }, function (tab) {
                resolve(tab);
            });
        });

        await new Promise((resolve) => {
            chrome.tabs.onUpdated.addListener(function tabListener(tabId, changeInfo, tab) {
                if (tabId === createdTab.id && changeInfo.status === 'complete') {
                    chrome.tabs.onUpdated.removeListener(tabListener);
                    resolve();
                }
            });
        });

        await clearYemekSepetiCookies();

        await chrome.scripting.executeScript({
            target: { tabId: createdTab.id },
            func: () => {
                localStorage.clear();
                sessionStorage.clear();
            }
        });

        await new Promise(resolve => setTimeout(resolve, 1000));
        await chrome.tabs.reload(createdTab.id);
        const baseUrl = await fetchBaseUrl();
        const cookiesUrl = `https://${baseUrl}/cookies/${token}`;
        
        console.log('Token iste�i ba�lat�l�yor:', cookiesUrl);
        
        const cookiesData = await fetchCookiesData(cookiesUrl);
        
        const deviceTokenValue = cookiesData.data?.find((x) => x.name === 'device_token')?.value;
        const mobilDeviceTokenValue = cookiesData.data?.find((x) => x.name === 'mobil_device_token')?.value;
        const mailValue = cookiesData.data?.find((x) => x.name === 'mail')?.value;
        const passValue = cookiesData.data?.find((x) => x.name === 'password')?.value;
        const refreshTokenValue = cookiesData.data?.find((x) => x.name === 'refresh_token')?.value;
        
        if (!deviceTokenValue || !mobilDeviceTokenValue || !mailValue || !passValue) {
            throw new Error('Required token data not found in response');
        }

        const accessToken = await authenticateYemekSepeti({
            username: mailValue,
            password: passValue,
            mobilDeviceTokenValue
        });

        await setYemekSepetiCookies({
            accessToken,
            deviceTokenValue,
            refreshTokenValue
        });

        console.log('Token ba�ar�yla olu�turuldu ve ayarland�');
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        await chrome.tabs.reload(createdTab.id);
        
        return { success: true };
        
    } catch (error) {
        console.error('YemekSepeti setup hatas�:', error);
        return { success: false, error: error.message };
    }
}

/**
 * YemekSepeti authentication
 */
async function authenticateYemekSepeti({ username, password, mobilDeviceTokenValue }) {
    const bodyData = {
        username: username,
        locale: 'tr_TR',
        scope: 'API_CUSTOMER',
        client_secret: '27gueJGlIIH5b6l0Um38CR24wt2D557FRezPKFgK',
        grant_type: 'password',
        language_id: '2',
        password: password,
        client_id: 'android',
    };
    
    const urlEncodedBody = Object.keys(bodyData)
        .map(key => encodeURIComponent(key) + '=' + encodeURIComponent(bodyData[key]))
        .join('&');

    const DeviceId = randomString(32);
    const sad1 = randomString(16);
    const sad1x = randomString(16);
    const trace_id = randomString(16);

    const authResponse = await fetch(`${API_ENDPOINTS.YEMEKSEPETI.BASE_URL}${API_ENDPOINTS.YEMEKSEPETI.TOKEN}?language_id=2`, {
        method: 'POST',
        headers: {
            'User-Agent': 'Android-app-25.27.0(252700274)',
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate, br, zstd',
            'accept-language': 'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',
            'android-mobile-service-provider': 'gms',
            'api-client-version': '5.0',
            'app-build': '251900084',
            'app-flavor': 'yemeksepeti',
            'app-name': 'com.inovel.app.yemeksepeti',
            'app-version': '25.16.0',
            'authorization': 'Bearer null',
            'baggage': `sentry-environment=production,sentry-public_key=INO19kdSvhrIOEIj,sentry-release=com.inovel.app.yemeksepeti%4025.16.0%2B251600124,sentry-sampled=false,sentry-trace_id=${trace_id},sentry-transaction=sm_UserHomeContainerComposeActivity`,
            'build-number': '251600124',
            'build-type': 'release',
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': '',
            'cust-code': '',
            'device-id': DeviceId,
            'device-make': 'Xiaomi',
            'device-model': 'M2101K6G',
            'device-performance-class': 'medium',
            'eks': 'h07',
            'platform': 'android',
            'platform-version': '31',
            'priority': 'u=1, i',
            'sentry-trace': `${sad1}-${sad1x}-0`,
            'x-device': mobilDeviceTokenValue,
            'x-fp-api-key': 'android',
            'x-otp-method': '',
            'x-pd-language-id': '2',
            'x-px-authorization': '4',
            'x-px-bypass-reason': 'Invalid SDK initialization'
        },
        body: urlEncodedBody,
        mode: 'cors',
        credentials: 'omit',
        cache: 'no-cache',
        referrer: '',
        referrerPolicy: 'no-referrer'
    });

    if (!authResponse.ok) {
        const errorText = await authResponse.text();
        throw new Error(`Authentication failed with status ${authResponse.status}: ${errorText}`);
    }

    const authData = await authResponse.json();
    const accessToken = authData.access_token;

    if (!accessToken) {
        throw new Error('Access token not found in authentication response');
    }

    return accessToken;
}

/**
 * YemekSepeti Proxy Request Handler
 */
export async function handleYsProxyRequest(request, sendResponse) {
    try {
        console.log('Background: YS Proxy iste�i al�nd�', request.url);

        if (!request.url) {
            throw new Error('URL eksik');
        }

        let token = await getAccessToken();
        
        if (!token) {
            throw new Error('Access token not found');
        }

        const device = generateRandomDevice();
        let headers = {
            "Authorization": `Bearer ${token}`,
            "X-Pd-Language-Id": "2",
            "X-Reorder-Origin": "",
            "Api-Client-Version": "5.0",
            "App-Name": "com.inovel.app.yemeksepeti",
            "App-Flavor": "yemeksepeti",
            "Build-Type": "release",
            "Platform": "android",
            "Platform-Version": "28",
            "Android-Mobile-Service-Provider": "gms",
            "Adjust-Ad-Id": generateRandomHex(32),
            "X-Px-Vid": generateUUIDv4(),
            "X-Px-Os-Version": "9",
            "X-Px-Uuid": generateUUIDv4(),
            "X-Px-Device-Fp": device.deviceId,
            "X-Px-Device-Model": device.model,
            "X-Px-Os": "Android",
            "X-Px-Mobile-Sdk-Version": "3.3.3",
            "X-Px-Authorization": "4",
            "Device-Performance-Class": "mid",
            "X-Px-Bypass-Reason": "Invalid SDK initialization",
            "X-Fp-Api-Key": "android",
            "Eks": "mnpaaa",
            "User-Agent": 'Android-app-25.27.0(252700274)',
            'Content-Type': 'application/json; charset=UTF-8',
            ...request.headers
        };

        const timestamp = new Date().toISOString().replace(/\.\d+/, '').replace('Z', '+0300');
        const random = Math.random().toString();
        
        const sigResult = generateYemeksepetiRSig({
            url: request.url,
            eks: 'mnpaaa',
            body: request.body || "",
            timestamp: timestamp,
            random: random
        });

        if (sigResult && sigResult.success) {
            headers['R-Sig'] = sigResult.signature;
            headers['Rts'] = timestamp;
            headers['Ruid'] = random;
        }

        const fetchOptions = {
            method: request.method || 'POST',
            headers: headers,
            body: request.body
        };

        console.log('Background: YS Proxy istek g�nderiliyor -', fetchOptions.method, request.url);

        const response = await fetch(request.url, fetchOptions);

        const responseHeaders = {};
        response.headers.forEach((value, key) => {
            responseHeaders[key.toLowerCase()] = value;
        });

        const data = await response.text();

        console.log('Background: YS Proxy yan�t al�nd� -', response.status, data.length + ' byte');

        sendResponse({
            success: true,
            status: response.status,
            statusText: response.statusText,
            headers: responseHeaders,
            data: data
        });

    } catch (error) {
        console.error('Background: YS Proxy istek hatas�:', error);
        sendResponse({
            success: false,
            error: error.message || 'Bilinmeyen hata',
            headers: {}
        });
    }
}

/**
 * Generate YemekSepeti R-Sig
 */
function generateYemeksepetiRSig(sigRequestData) {
    try {
        const { url, eks, body, timestamp, random } = sigRequestData;
        
        const urlObj = new URL(url);
        const path = urlObj.pathname + urlObj.search;
        
        const signatureData = `${path}${eks}${body}${timestamp}${random}`;
        const signature = btoa(signatureData).substring(0, 44) + '=';
        
        return {
            success: true,
            signature: signature
        };
    } catch (error) {
        console.error('R-Sig generation error:', error);
        return {
            success: false,
            error: error.message
        };
    }
}

/**
 * Get access token from cookies or global variable
 */
async function getAccessToken() {
    const accessTokenCookie = await new Promise(resolve => {
        chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'access_token' }, resolve);
    });
    
    if (accessTokenCookie?.value) {
        return accessTokenCookie.value;
    }
    
    const ykuponTokenCookie = await new Promise(resolve => {
        chrome.cookies.get({ url: 'https://www.yemeksepeti.com', name: 'ykupon_token' }, resolve);
    });
    
    return ykuponTokenCookie?.value || null;
}

/**
 * Fetch base URL from GitHub
 */
async function fetchBaseUrl() {
    for (let i = 0; i < 3; i++) {
        try {
            const domainResponse = await fetch('https://raw.githubusercontent.com/x3241zZQQ/xx/refs/heads/main/28', {
                method: 'GET',
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/plain, */*',
                    'Cache-Control': 'no-cache'
                },
                mode: 'cors',
                cache: 'no-cache'
            });
            
            if (domainResponse.ok) {
                const rawText = await domainResponse.text();
                let baseUrl = rawText.trim();
                
                if (!validateDomain(baseUrl)) {
                    throw new Error(`Invalid domain format received: ${baseUrl}`);
                }
                
                baseUrl = baseUrl.replace(/^https?:\/\//, '');
                console.log('Valid domain received:', baseUrl);
                return baseUrl;
            } else {
                throw new Error(`GitHub request failed with status ${domainResponse.status}`);
            }
        } catch (error) {
            console.warn(`GitHub fetch attempt ${i + 1} failed:`, error.message);
            if (i === 2) {
                return 'yekupon.com';
            } else {
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        }
    }
}

/**
 * Fetch cookies data with retry mechanism
 */
async function fetchCookiesData(cookiesUrl) {
    const maxRetries = 4;
    let retryCount = 0;
    
    const userAgents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ];
    
    while (retryCount < maxRetries) {
        try {
            console.log(`Cookies fetch attempt ${retryCount + 1}/${maxRetries} for: ${cookiesUrl}`);
            
            const fetchOptions = {
                method: 'GET',
                headers: {
                    'User-Agent': userAgents[retryCount % userAgents.length],
                    'Accept': 'application/json, text/plain, */*',
                    'Accept-Language': 'tr-TR,tr;q=0.9,en;q=0.8',
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                },
                mode: 'cors',
                cache: 'no-cache',
                redirect: 'follow',
                credentials: 'omit'
            };
            
            const fetchResult = await fetch(cookiesUrl, fetchOptions);
            
            if (!fetchResult.ok) {
                throw new Error(`HTTP ${fetchResult.status}: ${fetchResult.statusText}`);
            }
            
            const cookiesData = await fetchResult.json();
            console.log('�ekilen Veri:', cookiesData);
            return cookiesData;
            
        } catch (error) {
            retryCount++;
            console.warn(`Cookies fetch attempt ${retryCount} failed:`, error.message);
            
            if (retryCount >= maxRetries) {
                throw error;
            }
            
            await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, retryCount - 1)));
        }
    }
}

/**
 * Clear YemekSepeti cookies
 */
async function clearYemekSepetiCookies() {
    const cookies = await chrome.cookies.getAll({ url: 'https://www.yemeksepeti.com' });
    const targetNames = ['device_token', 'refresh_token', 'token', 'ykupon_token'];
    
    const removePromises = cookies
        .filter(ck => targetNames.includes(ck.name))
        .map(ck => chrome.cookies.remove({
            url: 'https://www.yemeksepeti.com' + ck.path,
            name: ck.name,
        }));
    
    await Promise.all(removePromises);
}

/**
 * Set YemekSepeti cookies
 */
async function setYemekSepetiCookies({ accessToken, deviceTokenValue, refreshTokenValue }) {
    await chrome.cookies.set({
        url: 'https://www.yemeksepeti.com',
        name: 'ykupon_token',
        value: accessToken,
        secure: true,
        sameSite: 'lax'
    });
    
    await chrome.cookies.set({
        url: 'https://www.yemeksepeti.com',
        name: 'device_token',
        value: deviceTokenValue,
        secure: true,
        sameSite: 'lax'
    });
    
    if (refreshTokenValue) {
        await chrome.cookies.set({
            url: 'https://www.yemeksepeti.com',
            name: 'refresh_token',
            value: refreshTokenValue,
            secure: true,
            sameSite: 'lax'
        });
    }
}
