import { randomString, generateUUIDv4, sendLogMessage, getSavedUserData } from '../core/helpers.js';
import { API_ENDPOINTS } from '../core/endpoints.js';

/**
 * Handle TgoYemek login process
 */
export async function handleTgoYemekLogin(data, token, tabId) {
    try {
        await sendLogMessage("TgoYemek giri� i�lemi ba�lat�l�yor...", "info", tabId, "TGOYEMEK");
        
        const response = await fetch(`${API_ENDPOINTS.YEKUPON.BASE_URL}${API_ENDPOINTS.YEKUPON.COOKIES}/${token}`);
        
        if (!response.ok) {
            throw new Error(`YeKupon sunucusu hatas�: ${response.status}`);
        }
        
        const responseData = await response.json();
        console.log('YeKupon sunucusundan al�nan veri:', responseData);
        
        const userData = responseData.data || responseData;
        
        chrome.storage.local.set({
            'yekupon_user_data': userData
        }, function() {
            console.log('YeKupon user data chrome storage\'a kaydedildi');
        });
        
        if (userData.email && userData.password) {
            await performTgoYemekDirectLogin(userData.email, userData.password, userData.phone_number, tabId);
        } else if (userData.access_token) {
            await performTgoYemekTokenLogin(userData, tabId);
        } else {
            throw new Error('YeKupon sunucusundan ge�ersiz veri format� al�nd�');
        }
        
    } catch (error) {
        console.error('TgoYemek giri� hatas�:', error);
        await sendLogMessage(`TgoYemek giri� hatas�: ${error.message}`, "error", tabId, "TGOYEMEK");
    }
}

/**
 * TgoYemek direct login with email and password
 */
export async function performTgoYemekDirectLogin(email, password, phoneNumber, tabId) {
    try {
        await sendLogMessage("TgoYemek �erezleri temizleniyor...", "info", tabId, "TGOYEMEK");
        
        await clearTgoYemekCookies();
        
        await sendLogMessage("CSRF token al�n�yor...", "info", tabId, "TGOYEMEK");
        
        const csrfResponse = await fetch(API_ENDPOINTS.TGOYEMEK.CSRF, {
            method: 'GET',
            headers: {
                'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
                'sec-ch-ua-mobile': '?0',
                'accept': '*/*',
                'sec-fetch-site': 'same-origin',
                'Content-Type': 'text/plain;charset=UTF-8',
                'sec-ch-ua-platform': '"Windows"',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr',
                'priority': 'u=1, i'
            }
        });
        
        if (!csrfResponse.ok) {
            throw new Error(`CSRF token al�namad�: ${csrfResponse.status}`);
        }
        
        const csrfData = await csrfResponse.json();
        const csrfToken = csrfData.csrfToken;
        
        if (!csrfToken) {
            throw new Error('CSRF token response\'�nda bulunamad�');
        }
        
        console.log('TgoYemek CSRF token al�nd�:', csrfToken);
        
        await new Promise((resolve, reject) => {
            chrome.cookies.set({
                url: "https://tgoyemek.com",
                name: "tgo-csrf-token",
                value: csrfToken,
                domain: "tgoyemek.com",
                secure: true,
                httpOnly: true,
                sameSite: "lax",
                path: "/"
            }, (cookie) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                } else {
                    resolve(cookie);
                }
            });
        });
        
        await sendLogMessage("TgoYemek'e giri� yap�l�yor...", "info", tabId, "TGOYEMEK");
        
        const loginResponse = await fetch(API_ENDPOINTS.TGOYEMEK.LOGIN, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138", "Microsoft Edge";v="138"',
                'sec-ch-ua-mobile': '?0',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0',
                'sec-ch-ua-platform': '"Windows"',
                'accept': '*/*',
                'origin': 'https://tgoyemek.com',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'referer': 'https://tgoyemek.com/giris?callbackUrl=%2F',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr,en;q=0.9,en-GB;q=0.8,en-US;q=0.7',
                'priority': 'u=1, i',
                'Cookie': `tgo-csrf-token=${csrfToken}`
            },
            body: JSON.stringify({
                username: email,
                password: password,
                csrfToken: csrfToken
            })
        });
        
        if (!loginResponse.ok) {
            throw new Error(`TgoYemek giri� ba�ar�s�z: ${loginResponse.status}`);
        }
        
        const loginData = await loginResponse.json();
        console.log('TgoYemek giri� yan�t�:', loginData);
        
        let tgoToken = null;
        
        const setCookieHeaders = loginResponse.headers.get('set-cookie');
        if (setCookieHeaders) {
            const tgoTokenMatch = setCookieHeaders.match(/tgo-token=([^;]+)/);
            if (tgoTokenMatch) {
                tgoToken = tgoTokenMatch[1];
                console.log('TgoYemek Header\'dan tgo-token al�nd�:', tgoToken.substring(0, 20) + '...');
            }
        }
        
        if (!tgoToken) {
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            const tgoTokenCookie = await new Promise(resolve => {
                chrome.cookies.get({ url: 'https://tgoyemek.com', name: 'tgo-token' }, cookie => {
                    resolve(cookie);
                });
            });
            
            if (tgoTokenCookie && tgoTokenCookie.value) {
                tgoToken = tgoTokenCookie.value;
                console.log('TgoYemek Cookie\'den tgo-token al�nd�:', tgoToken.substring(0, 20) + '...');
            }
        }
        
        if (!tgoToken) {
            throw new Error('tgo-token ne header\'da ne de cookie\'de bulunamad�');
        }
        
        const cookiePromises = [
            new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: "https://tgoyemek.com",
                    name: "tgo-token",
                    value: tgoToken,
                    domain: "tgoyemek.com",
                    secure: true,
                    httpOnly: true,
                    sameSite: "lax",
                    path: "/"
                }, (cookie) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(cookie);
                    }
                });
            }),
            new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: "https://tgoyemek.com",
                    name: "access_token",
                    value: tgoToken,
                    domain: "tgoyemek.com",
                    secure: true,
                    httpOnly: false
                }, (cookie) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(cookie);
                    }
                });
            }),
            new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: "https://tgoyemek.com",
                    name: "user_email",
                    value: email,
                    domain: "tgoyemek.com",
                    secure: true,
                    httpOnly: false
                }, (cookie) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(cookie);
                    }
                });
            }),
            new Promise((resolve, reject) => {
                chrome.cookies.set({
                    url: "https://tgoyemek.com",
                    name: "logged_in",
                    value: "true",
                    domain: "tgoyemek.com",
                    secure: true,
                    httpOnly: false
                }, (cookie) => {
                    if (chrome.runtime.lastError) {
                        reject(new Error(chrome.runtime.lastError.message));
                    } else {
                        resolve(cookie);
                    }
                });
            })
        ];
        
        if (phoneNumber) {
            cookiePromises.push(
                new Promise((resolve, reject) => {
                    chrome.cookies.set({
                        url: "https://tgoyemek.com",
                        name: "user_phone",
                        value: phoneNumber,
                        domain: "tgoyemek.com",
                        secure: true,
                        httpOnly: false
                    }, (cookie) => {
                        if (chrome.runtime.lastError) {
                            reject(new Error(chrome.runtime.lastError.message));
                        } else {
                            resolve(cookie);
                        }
                    });
                })
            );
        }
        
        await Promise.all(cookiePromises);
        
        const allCookies = await new Promise(resolve => {
            chrome.cookies.getAll({ domain: 'tgoyemek.com' }, cookies => {
                resolve(cookies);
            });
        });
        
        console.log('TgoYemek aktif cookie\'ler:', allCookies.map(c => `${c.name}=${c.value.substring(0, 20)}...`));
        
        await sendLogMessage("TgoYemek direkt giri�i ba�ar�l�!", "success", tabId, "TGOYEMEK");
        
        const userData = { 
            email: email, 
            access_token: tgoToken,
            tgo_token: tgoToken,
            phone_number: phoneNumber
        };
        
        chrome.storage.local.set({
            'yekupon_user_data': userData
        }, function() {
            console.log('YeKupon user data chrome storage\'a kaydedildi');
        });
        
        chrome.tabs.create({ url: "https://tgoyemek.com" });
        
        return { 
            success: true, 
            userData: userData
        };
        
    } catch (error) {
        console.error('TgoYemek direkt giri� hatas�:', error);
        await sendLogMessage(`TgoYemek direkt giri� hatas�: ${error.message}`, "error", tabId, "TGOYEMEK");
        return { success: false, error: error.message };
    }
}

/**
 * Token ile TgoYemek giri� (backward compatibility)
 */
export async function performTgoYemekTokenLogin(responseData, tabId) {
    try {
        await sendLogMessage("Token ile TgoYemek giri�i yap�l�yor...", "info", tabId, "TGOYEMEK");
        
        await setTgoYemekCookies(responseData, tabId);
        
        await sendLogMessage("TgoYemek token giri�i ba�ar�l�!", "success", tabId, "TGOYEMEK");
        
        chrome.tabs.create({ url: "https://tgoyemek.com" });
        
        return { success: true, userData: responseData };
        
    } catch (error) {
        console.error('TgoYemek token giri� hatas�:', error);
        await sendLogMessage(`TgoYemek token giri� hatas�: ${error.message}`, "error", tabId, "TGOYEMEK");
        return { success: false, error: error.message };
    }
}

/**
 * Get TgoYemek addresses
 */
export async function getTgoYemekAddresses() {
    try {
        console.log('TgoYemek adresleri al�n�yor (YeKupon bearer token)...');
        
        const savedUserData = await getSavedUserData();
        if (!savedUserData || !savedUserData.access_token) {
            console.log('YeKupon bearer token bulunamad�, bo� liste d�nd�r�l�yor');
            return [];
        }
        
        const bearerToken = savedUserData.access_token;
        console.log('YeKupon Bearer token al�nd� (TgoYemek i�in)');
        
        const response = await fetch(`${API_ENDPOINTS.TGOYEMEK.BASE_URL}${API_ENDPOINTS.TGOYEMEK.ADDRESSES}`, {
            method: 'GET',
            headers: {
                'accept': 'application/json, text/plain, */*',
                'accept-encoding': 'gzip, deflate, br, zstd',
                'accept-language': 'tr-TR,tr;q=0.9,en;q=0.8',
                'authorization': `Bearer ${bearerToken}`,
                'origin': 'https://tgoyemek.com',
                'referer': 'https://tgoyemek.com/',
                'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'cross-site',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'
            }
        });
        
        if (response.ok) {
            const addressData = await response.json();
            console.log('TgoYemek adresleri ba�ar�yla al�nd�:', addressData);
            return addressData.data || [];
        } else {
            console.error('TgoYemek adres listesi al�namad�:', response.status);
            return [];
        }
        
    } catch (error) {
        console.error('TgoYemek adres alma hatas�:', error);
        return [];
    }
}

/**
 * Clear TgoYemek cookies
 */
async function clearTgoYemekCookies() {
    const cookieNames = ['tgo-token', 'tgo-csrf-token', 'access_token', 'user_email', 'logged_in', 'user_phone'];
    
    for (const name of cookieNames) {
        try {
            await new Promise((resolve) => {
                chrome.cookies.remove({
                    url: "https://tgoyemek.com",
                    name: name
                }, resolve);
            });
        } catch (error) {
            console.error(`Cookie silme hatas� (${name}):`, error);
        }
    }
}

/**
 * Set TgoYemek cookies
 */
async function setTgoYemekCookies(data, tabId) {
    console.log('TgoYemek cookies being set');
}
