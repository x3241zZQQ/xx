document.addEventListener('DOMContentLoaded', function() {
    const statusDiv = document.getElementById('status');
    
    const migrosEmailInput = document.getElementById('migros-email');
    const migrosPasswordInput = document.getElementById('migros-password');
    const migrosLoginBtn = document.getElementById('migros-login');
    
    const tgoEmailInput = document.getElementById('tgo-email');
    const tgoPasswordInput = document.getElementById('tgo-password');
    const tgoPhoneInput = document.getElementById('tgo-phone');
    const tgoLoginBtn = document.getElementById('tgo-login');
    const tgoTokenInput = document.getElementById('tgo-token');
    const tgoTokenLoginBtn = document.getElementById('tgo-token-login');
    
    const ysEmailInput = document.getElementById('ys-email');
    const ysPasswordInput = document.getElementById('ys-password');
    const ysLoginBtn = document.getElementById('ys-login');
    
    const fullscreenBtn = document.getElementById('fullscreen-btn');
    const clearDataBtn = document.getElementById('clear-data-btn');
    const helpBtn = document.getElementById('help-btn');
    
    loadSavedCredentials();
    
    migrosLoginBtn.addEventListener('click', handleMigrosLogin);
    tgoLoginBtn.addEventListener('click', handleTgoLogin);
    tgoTokenLoginBtn.addEventListener('click', handleTgoTokenLogin);
    ysLoginBtn.addEventListener('click', handleYemekSepetiLogin);
    
    fullscreenBtn.addEventListener('click', openFullscreen);
    clearDataBtn.addEventListener('click', clearAllData);
    helpBtn.addEventListener('click', showHelp);
    
    [migrosEmailInput, migrosPasswordInput, tgoEmailInput, tgoPasswordInput, tgoPhoneInput, ysEmailInput, ysPasswordInput].forEach(input => {
        input.addEventListener('input', saveCredentials);
    });
    
    async function loadSavedCredentials() {
        try {
            const result = await chrome.storage.local.get([
                'migros_email', 'migros_password',
                'tgo_email', 'tgo_password', 'tgo_phone',
                'ys_email', 'ys_password'
            ]);
            
            if (result.migros_email) migrosEmailInput.value = result.migros_email;
            if (result.migros_password) migrosPasswordInput.value = result.migros_password;
            if (result.tgo_email) tgoEmailInput.value = result.tgo_email;
            if (result.tgo_password) tgoPasswordInput.value = result.tgo_password;
            if (result.tgo_phone) tgoPhoneInput.value = result.tgo_phone;
            if (result.ys_email) ysEmailInput.value = result.ys_email;
            if (result.ys_password) ysPasswordInput.value = result.ys_password;
            
        } catch (error) {
            console.error('Kaydedilmiş veriler yüklenemedi:', error);
        }
    }
    
    async function saveCredentials() {
        try {
            await chrome.storage.local.set({
                'migros_email': migrosEmailInput.value,
                'migros_password': migrosPasswordInput.value,
                'tgo_email': tgoEmailInput.value,
                'tgo_password': tgoPasswordInput.value,
                'tgo_phone': tgoPhoneInput.value,
                'ys_email': ysEmailInput.value,
                'ys_password': ysPasswordInput.value
            });
        } catch (error) {
            console.error('Veriler kaydedilemedi:', error);
        }
    }
    
    async function handleMigrosLogin() {
        const email = migrosEmailInput.value.trim();
        const password = migrosPasswordInput.value.trim();
        
        if (!email || !password) {
            showStatus('Email ve şifre gerekli!', 'error');
            return;
        }
        
        setButtonLoading(migrosLoginBtn, true);
        showStatus('Migros\'a giriş yapılıyor...', 'info');
        
        try {
            const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
            const tabId = tabs[0].id;
            
            const response = await chrome.runtime.sendMessage({
                action: 'setupMigros',
                userData: {
                    username: email,
                    password: password
                },
                tabId: tabId
            });
            
            if (response.success) {
                showStatus('? Migros giriş başarılı!', 'success');
                setTimeout(() => window.close(), 2000);
            } else {
                showStatus('? Migros giriş başarısız: ' + (response.error || 'Bilinmeyen hata'), 'error');
            }
            
        } catch (error) {
            console.error('Migros login error:', error);
            showStatus('? Migros giriş hatası: ' + error.message, 'error');
        } finally {
            setButtonLoading(migrosLoginBtn, false);
        }
    }
    
    async function handleTgoLogin() {
        const email = tgoEmailInput.value.trim();
        const password = tgoPasswordInput.value.trim();
        const phone = tgoPhoneInput.value.trim();
        
        if (!email || !password) {
            showStatus('Email ve şifre gerekli!', 'error');
            return;
        }
        
        setButtonLoading(tgoLoginBtn, true);
        showStatus('TgoYemek\'e giriş yapılıyor...', 'info');
        
        try {
            const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
            const tabId = tabs[0].id;
            
            const response = await chrome.runtime.sendMessage({
                action: 'setupTgoYemek',
                userData: {
                    username: email,
                    password: password,
                    phone: phone
                },
                tabId: tabId
            });
            
            if (response.success) {
                showStatus('? TgoYemek giriş başarılı!', 'success');
                setTimeout(() => window.close(), 2000);
            } else {
                showStatus('? TgoYemek giriş başarısız: ' + (response.error || 'Bilinmeyen hata'), 'error');
            }
            
        } catch (error) {
            console.error('TgoYemek login error:', error);
            showStatus('? TgoYemek giriş hatası: ' + error.message, 'error');
        } finally {
            setButtonLoading(tgoLoginBtn, false);
        }
    }
    
    async function handleTgoTokenLogin() {
        const token = tgoTokenInput.value.trim();
        
        if (!token) {
            showStatus('Token gerekli!', 'error');
            return;
        }
        
        setButtonLoading(tgoTokenLoginBtn, true);
        showStatus('Token ile giriş yapılıyor...', 'info');
        
        try {
            const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
            const tabId = tabs[0].id;
            
            const response = await chrome.runtime.sendMessage({
                action: 'setupTgoYemekToken',
                userData: {
                    accessToken: token
                },
                tabId: tabId
            });
            
            if (response.success) {
                showStatus('? Token giriş başarılı!', 'success');
                setTimeout(() => window.close(), 2000);
            } else {
                showStatus('? Token giriş başarısız: ' + (response.error || 'Bilinmeyen hata'), 'error');
            }
            
        } catch (error) {
            console.error('TgoYemek token login error:', error);
            showStatus('? Token giriş hatası: ' + error.message, 'error');
        } finally {
            setButtonLoading(tgoTokenLoginBtn, false);
        }
    }
    
    async function handleYemekSepetiLogin() {
        const email = ysEmailInput.value.trim();
        const password = ysPasswordInput.value.trim();
        
        if (!email || !password) {
            showStatus('Email ve şifre gerekli!', 'error');
            return;
        }
        
        setButtonLoading(ysLoginBtn, true);
        showStatus('YemekSepeti\'ne giriş yapılıyor...', 'info');
        
        try {
            const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
            const tabId = tabs[0].id;
            
            const response = await chrome.runtime.sendMessage({
                action: 'setupYemekSepeti',
                userData: {
                    username: email,
                    password: password
                },
                tabId: tabId
            });
            
            if (response.success) {
                showStatus('? YemekSepeti giriş başarılı!', 'success');
                setTimeout(() => window.close(), 2000);
            } else {
                showStatus('? YemekSepeti giriş başarısız: ' + (response.error || 'Bilinmeyen hata'), 'error');
            }
            
        } catch (error) {
            console.error('YemekSepeti login error:', error);
            showStatus('? YemekSepeti giriş hatası: ' + error.message, 'error');
        } finally {
            setButtonLoading(ysLoginBtn, false);
        }
    }
    
    function openFullscreen() {
        chrome.tabs.create({
            url: chrome.runtime.getURL('fullscreen.html'),
            active: true
        });
        window.close();
    }
    
    async function clearAllData() {
        if (confirm('Tüm kaydedilmiş veriler silinecek. Emin misiniz?')) {
            try {
                await chrome.storage.local.clear();
                
                [migrosEmailInput, migrosPasswordInput, tgoEmailInput, tgoPasswordInput, tgoPhoneInput, tgoTokenInput, ysEmailInput, ysPasswordInput].forEach(input => {
                    input.value = '';
                });
                
                showStatus('? Tüm veriler temizlendi!', 'success');
                
            } catch (error) {
                console.error('Data clear error:', error);
                showStatus('? Veri temizleme hatası: ' + error.message, 'error');
            }
        }
    }
    
    function showHelp() {
        const helpText = `

        `.trim();
        
        alert(helpText);
    }
    
    function showStatus(message, type) {
        statusDiv.textContent = message;
        statusDiv.className = `status ${type}`;
        statusDiv.style.display = 'block';
        
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 5000);
    }
    
    function setButtonLoading(button, loading) {
        if (loading) {
            button.disabled = true;
            button.textContent = 'İşleniyor...';
        } else {
            button.disabled = false;
            const originalTexts = {
                'migros-login': 'Migros\'a Giriş Yap',
                'tgo-login': 'TgoYemek\'e Giriş Yap',
                'tgo-token-login': 'Token ile Giriş',
                'ys-login': 'YemekSepeti\'ne Giriş Yap'
            };
            button.textContent = originalTexts[button.id] || 'Giriş Yap';
        }
    }
    
    console.log('YeKupon Popup loaded successfully');
});
